package com.demo.samples.day8.designpatterns.creational.factory;

public interface Notification {
    void notifyUser();
}
