package com.demo.oops;

/*
 This class is used to store Voter details
 */
public class Voter {


    /* Parameterised constructor */
    public Voter(String name, int age) {

    }

    /*Getters and Setters*/
    public String getName() {
        return null;
    }

    public void setName(String name) {

    }

    public int getAge() {
        return -1;
    }

    public void setAge(int age) {

    }

    /*
       Returns Voter details in a formatted String
    */
    @Override
    public String toString() {
        return null;
    }

    /*
        Returns the age criteria of voter based on the below criteria
            ADULT : >=18
            UNDERAGE : < 18
     */
    public String getAgeCriteria() {
        return null;
    }
}
